package com.service;

import java.util.List;

import com.entities.Student;
import com.exception.InvalidCollegeException;
import com.exception.InvalidStudentException;

public interface IStudentService {
    
	public Student addStudent(Student student, String collegeId) throws InvalidCollegeException;
	public Student updateScore(String studentId, int score) throws InvalidStudentException;
	public Student viewStudentById(String studentId) throws InvalidStudentException;
	public List<Student> viewStudentsByCollegeName(String collegeName);
	public Student deleteStudent(String studentId) throws InvalidStudentException;	
}