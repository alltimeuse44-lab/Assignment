package com.exception;

public class InvalidCollegeException extends Exception {
    
    
}
