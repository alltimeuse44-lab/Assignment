package com.repository;

import java.util.List;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.entities.Student;

//Provide necessary annotation
@Repository
public interface StudentRepository extends CrudRepository<Student,String> {

	List<Student> findByCollegeObjCollegeName(String collegeName);

//Provide necessary methods to view Students based on a given college name.

}
