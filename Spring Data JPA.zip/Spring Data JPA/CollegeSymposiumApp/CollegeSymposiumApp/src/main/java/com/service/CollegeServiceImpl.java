package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.repository.CollegeRepository;
import com.entities.College;
import com.exception.InvalidCollegeException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CollegeServiceImpl implements ICollegeService{
	
	//Provide necessary annotation
	@Autowired
    private CollegeRepository collegeRepo;

	public College addCollege(College college) {
		return this.collegeRepo.save(college);
	}

	public College updateRewardPoints(String collegeId, int rewardPoints) throws InvalidCollegeException {
		College college = collegeRepo.findById(collegeId).orElseThrow(()->new InvalidCollegeException());
		college.setRewardPoints(rewardPoints);
		return collegeRepo.save(college);
	}

	public List<College> viewCollegeByRewardPointsRange(int minLimit, int maxLimit) {
		return this.collegeRepo.findByRewardPointsBetween(minLimit,maxLimit);
	}

	public List<College> viewCollegeByCityAndCollegeType(String city,String collegeType) {
		return this.collegeRepo.findByCityAndCollegeType(city,collegeType);
	}

	public Map<String,Integer> getStudentCountCollegeWise() {
		List<Object[]> list = this.collegeRepo.findByCollegeWise();
		Map<String,Integer> resultMap = new HashMap<>();
		for(Object[] obj : list) {
			resultMap.put((String) obj[0], (int)((long)obj[1]));
		}
		return resultMap;
	}
}
	 	  	      	 		     	     	        	 	
