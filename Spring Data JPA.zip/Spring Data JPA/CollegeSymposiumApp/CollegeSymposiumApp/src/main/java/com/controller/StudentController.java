package com.controller;

import java.util.List;
import com.entities.Student;
import com.exception.InvalidCollegeException;
import com.exception.InvalidStudentException;
import com.service.IStudentService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

//Provide necessary Annotation
@RestController
public class StudentController {
	
	
	//Provide necessary Annotation
	@Autowired
	private IStudentService studentService;

	//Provide necessary Annotation for the below methods and fill the code
	@PostMapping("/addStudent/{collegeId}")
	public ResponseEntity<Student> addStudent(@Valid @RequestBody Student student,@PathVariable String collegeId) throws InvalidCollegeException {
		return ResponseEntity.ok(studentService.addStudent(student, collegeId));
	}
	
	@PutMapping("/updateScore/{studentId}/{score}")
	public ResponseEntity<Student> updateScore(@PathVariable("studentId") String studentId,@PathVariable("score") int score) throws InvalidStudentException {
		return ResponseEntity.ok(studentService.updateScore(studentId, score));
	}
	@GetMapping("/viewStudentById/{studentId}")
	public ResponseEntity<Student> viewStudentById(@PathVariable("studentId") String studentId) throws InvalidStudentException {
		return ResponseEntity.ok(studentService.viewStudentById(studentId));
	}
	@GetMapping("/viewStudentByCollegeName/{collegeName}")
	public ResponseEntity<List<Student>> viewStudentsByCollegeName(@PathVariable("collegeName") String collegeName) {
		return ResponseEntity.ok(studentService.viewStudentsByCollegeName(collegeName));
	}
	@DeleteMapping("/deleteStudent/{studentId}")
	public ResponseEntity<Student> deleteStudent(@PathVariable("studentId") String studentId) throws InvalidStudentException {
		return ResponseEntity.ok(studentService.deleteStudent(studentId));
	}
}
