package com.entities;

import java.util.List;

import org.hibernate.validator.constraints.Range;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


//Provide necessary Annotation wherever necessary
// Use appropriate lombok annotations for auto-generating constructor/getter/setter 
// OR manually define the constructor/getter/setter methods, but not both.

@Data
@Getter
@Setter
@AllArgsConstructor
@Entity
public class College {

	//Provide necessary Annotation 
	@Id
	@NotNull(message="Provide value for college id")
	@Column(name="college_id",length=25)
	private String collegeId;
	@NotNull(message="Provide value for college name")
	@Column(name="college_name",length=25)
	private String collegeName;
	@NotNull(message = "Provide value for city")
	@Column(name="city",length=25)
	private String city;
	@NotNull(message="Provide value for college type")
	@Column(name="college_type",length=25)
	private String collegeType;
	@Range(min=0,max=10,message="Reward points should be between 0 and 10")
	private int rewardPoints;
	
	//Provide necessary Annotations
	@OneToMany(mappedBy="collegeObj")
	private List<Student> studentList;
	
	
	public College() {
		super();
	}

}
