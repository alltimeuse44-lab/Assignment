package com.entities;

import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

//Provide necessary Annotation wherever necessary
// Use appropriate lombok annotations for auto-generating constructor/getter/setter 
// OR manually define the constructor/getter/setter methods, but not both.
@Entity
@Getter
@Setter
@Data
@AllArgsConstructor
public class Student {

	//Provide necessary Annotation
	@Id
	@NotNull(message="Provide value for student id")
	@Column(name="student_id",length=25)
	private String studentId;
	@NotNull(message="Provide value for name")
	@Column(name="name",length=25)
	private String name;
	@NotNull(message="Provide value for department")
	@Column(name="department",length=25)
	private String department;
	@NotNull(message="Provide value for activity type")
	@Column(name="activity_type",length=25)
	private String activityType;
	@PositiveOrZero(message="Score should be greater than or equal to zero")
	private int score;

	//Provide necessary Annotation
	@ManyToOne
	@JoinColumn(name="college_id")
	private College collegeObj;

	public Student() {
		super();
	}

}
