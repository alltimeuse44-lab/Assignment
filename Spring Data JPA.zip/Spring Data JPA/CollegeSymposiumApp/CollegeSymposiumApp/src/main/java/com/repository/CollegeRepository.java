package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entities.College;

//Provide necessary annotation
@Repository
public interface CollegeRepository extends JpaRepository<College,String>{

	
	List<College> findByRewardPointsBetween(int minLimit, int maxLimit);

	
	
	List<College> findByCityAndCollegeType(String city, String collegeType);

	@Query("select c.collegeId,size(c.studentList) from College c")
	List<Object[]> findByCollegeWise();

	//Provide necessary methods to view College by reward points between a given range and
	//view college based on a given city and college type and to get student count college wise

}
