package com.exception;

public class InvalidStudentException extends Exception  {
    
    
}
