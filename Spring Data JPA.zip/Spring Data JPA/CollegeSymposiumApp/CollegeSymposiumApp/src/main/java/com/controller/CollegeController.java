package com.controller;

import java.util.List;

import java.util.Map;
import com.entities.College;
import com.exception.InvalidCollegeException;
import com.service.ICollegeService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

//Provide necessary Annotation
@RestController
public class CollegeController {
	
	//Provide necessary Annotation
	@Autowired
	private ICollegeService collegeService;
	
	//Provide necessary Annotation for the below methods and fill the code
	@PostMapping("/addCollege")
	public ResponseEntity<College> addCollege( @Valid @RequestBody College college) {
		return ResponseEntity.ok(collegeService.addCollege(college));
	}
	
	@PutMapping("/updateRewardPoints/{collegeId}/{rewardPoints}")
	public ResponseEntity<College> updateRewardPoints(@PathVariable("collegeId") String collegeId,@PathVariable("rewardPoints") int rewardPoints) throws InvalidCollegeException {
		return ResponseEntity.ok(collegeService.updateRewardPoints(collegeId, rewardPoints));
	}

	@GetMapping("viewCollegeByRewardPointsRange/{minLimit}/{maxLimit}")
    public ResponseEntity<List<College>> viewCollegeByRewardPointsRange(@PathVariable("minLimit") int minLimit,@PathVariable("maxLimit") int maxLimit){
        return ResponseEntity.ok(collegeService.viewCollegeByRewardPointsRange(minLimit, maxLimit));
    }
	@GetMapping("viewCollegeByCityAndCollegeType/{city}/{collegeType}")
	public ResponseEntity<List<College>> viewCollegeByCityAndCollegeType(@PathVariable("city") String city,@PathVariable("collegeType") String collegeType) {
		return ResponseEntity.ok(collegeService.viewCollegeByCityAndCollegeType(city, collegeType));
	}
	@GetMapping("/getStudentCountCollegeWise")
	public ResponseEntity<Map<String,Integer>> getStudentCountCollegeWise() {
		return ResponseEntity.ok(collegeService.getStudentCountCollegeWise());
	}

}

