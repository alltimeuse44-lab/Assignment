package com.service;

import java.util.List;
import java.util.Map;

import com.entities.College;
import com.exception.InvalidCollegeException;

public interface ICollegeService {
	
	public College addCollege(College college);
	public College updateRewardPoints(String collegeId, int rewardPoints) throws InvalidCollegeException;
	public List<College> viewCollegeByRewardPointsRange(int minLimit, int maxLimit);
	public List<College> viewCollegeByCityAndCollegeType(String city,String collegeType);
	public Map<String,Integer> getStudentCountCollegeWise();
}
