package com.service;

import java.util.List;
import java.util.Optional;

import com.entities.Employer;
import com.entities.JobPost;
import com.exception.InvalidEmployerException;
import com.exception.InvalidJobPostException;
import com.repository.EmployerRepository;
import com.repository.JobPostRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JobPostServiceImpl implements IJobPostService {

	// Provide necessary Annotation
	@Autowired
	private JobPostRepository jobRepository;

	// Provide necessary Annotation
	@Autowired 
	private EmployerRepository empRepository;

	public JobPost addJobPost(JobPost jobPostObj, String employerId) throws InvalidEmployerException
	{
		Optional<Employer> emp = this.empRepository.findById(employerId);
		
		if(emp.isEmpty()) {
			throw new InvalidEmployerException();
		}
		
		jobPostObj.setEmployerObj(emp.get());
		
		this.jobRepository.save(jobPostObj);
		
		return jobPostObj;
	}
	
	public JobPost updateOfferedSalary(String jobId, double salaryOffered) throws InvalidJobPostException
	{
		Optional<JobPost> job = this.jobRepository.findById(jobId);
		
		if(job.isPresent()) {
			job.get().setSalaryOffered(salaryOffered);
			this.jobRepository.save(job.get());
			return job.get();
		} else {
			throw new InvalidJobPostException();
		}
		
	}	
	
	public List<JobPost> viewJobsBySalaryOffered(double salaryOffered)
	{
		return this.jobRepository.findBySalaryOfferedGreaterThanEqual(salaryOffered);
	}
	
	public List<JobPost> viewJobsByCompanyAndLocation(String companyName, String location){
		return this.jobRepository.findByEmployerObjCompanyNameEqualsAndEmployerObjLocationEquals(companyName, location);
	}
	
	public JobPost markJobPostAsClosed(String jobId) throws InvalidJobPostException {
		Optional<JobPost> job = this.jobRepository.findById(jobId);
		
		if(job.isEmpty()) {
			throw new InvalidJobPostException();
		}
		
		this.jobRepository.delete(job.get());
		
		return job.get();
	
	}
}
