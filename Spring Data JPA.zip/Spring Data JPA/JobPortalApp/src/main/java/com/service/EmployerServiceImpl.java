package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.entities.Employer;
import com.exception.InvalidEmployerException;
import com.repository.EmployerRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployerServiceImpl implements IEmployerService {
		// Provide necessary Annotation
		@Autowired
		private EmployerRepository empRepository;

		public Employer addEmployer(Employer employerObj) {
			this.empRepository.save(employerObj);
			return employerObj;
		}
		
		public Employer updateLocation(String employerId, String location) throws InvalidEmployerException
		{
			Optional<Employer> existingEmployee = this.empRepository.findById(employerId);
			
			if(existingEmployee.isPresent()) {
				existingEmployee.get().setLocation(location);
				this.empRepository.save(existingEmployee.get());
			} else {
				throw new InvalidEmployerException();
			}
			
			return existingEmployee.get();
		}
		
		public Employer viewEmployerById(String employerId) throws InvalidEmployerException
		{
			Optional<Employer> emp = this.empRepository.findById(employerId);
			
			if(emp.isEmpty()) {
				throw new InvalidEmployerException();
			}
			
			return emp.get();
		}
		
		public List<Employer> viewEmployersByIndustry(String industry)
		{	
			return this.empRepository.findByIndustry(industry);
		}
		
		public List<Employer> viewEmployersByJobTitle(String title){
			return this.empRepository.findByJobPostingsListTitle(title);
		}
		
		public Map<String,Integer> getEmployerWiseJobCount(){
//			return this.empRepository.getEmployerJobCount();
//			return this.empRepository.findAll().stream().collect(Collectors.toMap(emp -> emp.getEmployerId(), emp -> emp.getJobPostingsList().size()));
			
			List<Object[]> result = this.empRepository.getEmployerJobCount();
			
			Map<String,Integer> resultMap = new HashMap<>();
			
			for(Object[] res : result) {
				String employerId = (String) res[0];
				int Count =(int) res[1];
				resultMap.put(employerId, Count);
			}
			
			return resultMap;
			
		}
		
}
