package com.exception;

public class InvalidEmployerException  extends Exception {
	
	public InvalidEmployerException() {
		super();
	}
	
}
