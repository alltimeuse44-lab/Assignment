package com.exception;

public class InvalidJobPostException extends Exception {

	public InvalidJobPostException() {
		super();
	}
	
}
