package com.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entities.Employer;
import com.exception.InvalidEmployerException;
import com.service.IEmployerService;

//Provide necessary Annotation
@RestController
public class EmployerController {

	// Provide necessary Annotation
	@Autowired
	private IEmployerService employerService;
	
	
	@PostMapping("/addEmployer")
	public ResponseEntity<Employer> addEmployer(@RequestBody Employer employerObj) {
		return ResponseEntity.ok(this.employerService.addEmployer(employerObj));
	}
	
	@PutMapping("/updateLocation/{employerId}/{location}")
	public ResponseEntity<Employer> updateLocation(@PathVariable String employerId, @PathVariable String location) throws InvalidEmployerException {
		return ResponseEntity.ok(this.employerService.updateLocation(employerId, location));
	}
	
	@GetMapping("/viewEmployerById/{employerId}")
	public ResponseEntity<Employer> viewEmployerById(@PathVariable String employerId) throws InvalidEmployerException {
		return ResponseEntity.ok(this.employerService.viewEmployerById(employerId));
	}
	
	@GetMapping("/viewEmployersByIndustry/{industry}")
	public ResponseEntity<List<Employer>> viewEmployersByIndustry(@PathVariable String industry) {
		return ResponseEntity.ok(this.employerService.viewEmployersByIndustry(industry));
	}
	
	@GetMapping("/viewEmployersByJobTitle/{title}")
	public ResponseEntity<List<Employer>> viewEmployersByJobTitle(@PathVariable String title)  {
		return ResponseEntity.ok(this.employerService.viewEmployersByJobTitle(title));
	}
	
	@GetMapping("/getEmployerWiseJobCount")
	public ResponseEntity<Map<String,Integer>> getEmployerWiseJobCount() {
		return ResponseEntity.ok(this.employerService.getEmployerWiseJobCount());
	}

	
}
