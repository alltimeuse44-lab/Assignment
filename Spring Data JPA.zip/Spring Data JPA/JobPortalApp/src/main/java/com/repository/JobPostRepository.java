package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.entities.JobPost;

//Provide necessary annotation
@Repository
public interface JobPostRepository extends JpaRepository<JobPost, String>{

//	 Provide necessary method methods to view JobPosts by salaryOffered, and view 
	List<JobPost> findBySalaryOfferedGreaterThanEqual(double salaryOffered);

	List<JobPost> findByEmployerObjCompanyNameEqualsAndEmployerObjLocationEquals(String companyName, String location);

//	JobPosts by companyName and location	
}