package com.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entities.Employer;

//Provide necessary annotation
@Repository
public interface EmployerRepository extends JpaRepository<Employer, String>  {

	//Provide necessary method to view employer based on industry,
	List<Employer> findByIndustry(String industry);

	//to view Employers by JobPost title and to get the Employer wise total JobPost count 
	List<Employer> findByJobPostingsListTitle(String title);
	
	@Query("Select emp.employerId, size(emp.jobPostingsList) From Employer emp")
	List<Object[]> getEmployerJobCount();
}