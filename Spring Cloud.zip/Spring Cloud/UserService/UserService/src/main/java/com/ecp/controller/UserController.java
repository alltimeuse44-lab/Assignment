package com.ecp.controller;

import com.ecp.model.User;
import com.ecp.service.UserService;


public class UserController {
	
	
	private UserService service;
	
	
	public boolean add(User user)
	{
		return false;
	}

}
