package com.ecp.controller;


import com.ecp.model.Order;
import com.ecp.service.OrderService;


public class OrderController {


	private OrderService service;
	
	
	public boolean add(Order order)
	{
		return false;
	}
	
}
