package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entities.Dealer;

//Provide necessary annotation
@Repository
public interface DealerRepository extends JpaRepository<Dealer, String> {

	List<Dealer> findByLocationEqualsAndAuthorizedBrandEquals(String location, String authorizedBrand);

	@Query("select d.dealerId, size(d.laptopList) from Dealer d")
	List<Object[]> getLaptopCount();	
	
	// Provide necessary methods to view dealers by location and brand and to view available laptop count dealerwise

}
