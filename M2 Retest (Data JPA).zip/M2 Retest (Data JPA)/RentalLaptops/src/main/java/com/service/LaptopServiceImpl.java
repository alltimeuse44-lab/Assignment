package com.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entities.Dealer;
import com.entities.Laptop;
import com.exception.InvalidLaptopException;
import com.exception.InvalidDealerException;
import com.repository.LaptopRepository;
import com.repository.DealerRepository;

@Service
public class LaptopServiceImpl implements ILaptopService {

    // Provide necessary Annotation
	@Autowired
    private LaptopRepository laptopRepository;

    // Provide necessary Annotation
	@Autowired
    private DealerRepository dealerRepository;

   
    public Laptop addLaptop(Laptop laptop, String dealerId) throws InvalidDealerException {
       // Fill the code
    	Dealer dealer = dealerRepository.findById(dealerId).orElseThrow(()->new InvalidDealerException());
		laptop.setDealerObj(dealer);
    	return laptopRepository.save(laptop);
    }

   
    public Laptop updateAvailabilityStatus(String laptopId, String availabilityStatus) throws InvalidLaptopException {
      // Fill the code
    	Laptop laptop = laptopRepository.findById(laptopId).orElseThrow(()->new InvalidLaptopException());
		laptop.setAvailabilityStatus(availabilityStatus);
    	return laptopRepository.save(laptop);
    }

   
   
    public List<Laptop> viewLaptopsWithRam(int ram) {
       // Fill the code
		return laptopRepository.findByRamGreaterThanEqual(ram);
    }
   
    public List<Laptop> viewLaptopsByDealerId(String dealerId) {
        // Fill the code
		return laptopRepository.findByDealerObjDealerId(dealerId);
    }

   
    public Laptop scrapALap(String laptopId) throws InvalidLaptopException {
       // Fill the code
		Laptop lap = laptopRepository.findById(laptopId).orElseThrow(()->new InvalidLaptopException());
		laptopRepository.delete(lap);
		return lap;
    }
}
