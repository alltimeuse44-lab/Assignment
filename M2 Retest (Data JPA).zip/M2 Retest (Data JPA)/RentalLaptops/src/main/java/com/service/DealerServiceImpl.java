package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.entities.Dealer;
import com.exception.InvalidDealerException;
import com.repository.DealerRepository;

@Service
public class DealerServiceImpl implements IDealerService {

   // Provide necessary Annotation
	@Autowired
    private DealerRepository dealerRepository;

    
    public Dealer addDealer(Dealer dealer) {
        // fill code
	    return dealerRepository.save(dealer);
    }

  
    public Dealer updateRating(String dealerId, int rating) throws InvalidDealerException {
       // fill code
    	Dealer dealer = dealerRepository.findById(dealerId).orElseThrow(()->new InvalidDealerException());
	    dealer.setRating(rating);
    	return dealerRepository.save(dealer);
    }

 
    public Dealer viewDealerById(String dealerId) throws InvalidDealerException {
       
	// fill code
	    return dealerRepository.findById(dealerId).orElseThrow(()->new InvalidDealerException());
    }

    
    public List<Dealer> viewDealersByLocationAndBrand(String location, String authorizedBrand) {
	// fill code
	    return dealerRepository.findByLocationEqualsAndAuthorizedBrandEquals(location,authorizedBrand);
    }

  
    public Map<String, Integer> getAvailableLaptopCountDealerWise() {
	// fill code
    	Map<String, Integer> map = new HashMap<>();
    	List<Object[]> list = dealerRepository.getLaptopCount();
    	
    	for(Object[] obj: list) {
    		map.put((String)obj[0], (int)obj[1]);
    	}
	    return map;
    }

}
