package com.entities;

import java.util.List;

import org.hibernate.validator.constraints.Range;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


//Provide necessary Annotation wherever necessary
@Entity
@Getter
@Setter
@AllArgsConstructor
public class Dealer {

    // Provide necessary Annotation
	@Id
	@NotNull(message = "Provide value for dealer Id")
	@Column(name="dealer_id", length=25)
    private String dealerId;
	
	@NotNull(message="Provide value for dealer name")
	@Column(name="dealer_name", length=25)
    private String dealerName;
	
	@NotNull(message="Provide value for location")
	@Column(name="location", length=25)
    private String location;
	
	@NotNull(message="Provide value for email")
	@Column(name="email", length=25)
    private String email;
	
	@Range(min=1, max=10, message="Rating should be in between 1 and 10")
    private int rating;
	
	@NotNull(message="Provide value for authorized brand")
	@Column(name="authorization_brand", length=25)
    private String authorizedBrand;
	
	@NotNull(message="Provide value for service type")
	@Column(name="service_type", length=25)
    private String serviceType;

    // Provide necessary Annotation
    @OneToMany(mappedBy="dealerObj")
    private List<Laptop> laptopList;

	public Dealer()
	{
	   super();
	}
}
