package com.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

//Provide necessary Annotation wherever necessary
@Entity
@Getter
@Setter
@AllArgsConstructor
public class Laptop {

    // Provide necessary Annotation
	@Id
	@NotNull(message="Provide value for laptop Id")
	@Column(name="laptop_id", length=25)
    private String laptopId;
	
	@NotNull(message="Provide value for laptop brand")
	@Column(name="brand", length=25)
    private String brand;
	
	@NotNull(message="Provide value for laptop model")
	@Column(name="model", length=25)
    private String model;
	
	@Column(name="processor", length=25)
	@NotNull(message="Provide value for processor")
    private String processor;
	
	@Positive(message="Ram should be greater than zero")
    private int ram;
	@Positive(message="Storage should be greater than zero")
    private int storage;
	@Positive(message="Rental price should be greater than zero")
    private double rentalPrice;
	@NotNull(message="Provide value for availability status")
	@Column(name="availability_status", length=25)
    private String availabilityStatus;
    // Provide necessary Annotations
    @ManyToOne
    @JoinColumn(name="dealer_id")
    private Dealer dealerObj;

	public Laptop()
	{
	   super();
        }
}
