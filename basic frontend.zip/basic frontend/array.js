// 	Create an array of numbers, print all elements, length, and sum.
// Find the largest number in an array.

let numbers = [3, 7, 5, 8, 2];
console.log('numbers: ', numbers);

console.log('length: ', numbers.length);

let max_num=0, sum=0;
for(let i=0; i<numbers.length; i++){
    sum += numbers[i];
    if(numbers[i] > max_num){
        max_num = numbers[i];
    }
}
console.log('Sum ', sum);
console.log('largest Number: ', max_num);
// Create a student object with name, age, and marks. Print all values.

const student = {
    name : 'Raj',
    age : 23,
    marks: 56
};
console.log('Name: ', student.name);
console.log('age', student.age);
console.log('marks', student.marks);

// Create an array of student objects and print each student name.

const players = [
    {name: 'Virat', age: 37},
    {name: 'Rohit', age: 38},
    {name: 'Surya', age: 35}
]
console.log('----------------');
for(let player of players)
console.log(player.name);

players.forEach(player => console.log(player.name));

function calculateInterst(p, r, t){
    return (p*r*t)/100;
}
console.log('simple interest: ', calculateInterst(200000, 8, 2));

// Count how many times a number occurs in an array.

const nums = [1, 2, 3, 2, 4, 2];

const freq = nums.reduce((acc, current) => {
  acc[current] = (acc[current] || 0) + 1;
  return acc;
}, {});

console.log(freq); 

let count=0;
for(let num of nums){
    if(num===2) count++;
}
console.log('count: ', count);


// Check pass/fail status for students stored in an array of objects.

const studObj = [
    { name: 'Pradyumna', marks: '43'},
    { name: 'Aditya', marks: '39'},
    { name: 'Gyan', marks: '87'},
    { name: 'Rishabh', marks: '93'}
];


studObj.forEach(stud => {
    if(stud.marks > 50){
        console.log(`${stud.name}: Pass` );
    }
    else{
        console.log(`${stud.name}: Fail`);
    }
});

const even = numbers.filter(n=>n%2==0);
const odd = numbers.filter(n=>n%2==1);

console.log('even numbers: ', even);
console.log('odd numbers: ', odd);



