package com.repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.entities.Employer;
import com.entities.JobPost;

//Provide necessary annotation
@Repository
public interface EmployerRepository extends JpaRepository<Employer, String> {

	//Provide necessary method to view employer based on industry	
	//to view Employers by JobPost title and to get the Employer wise total JobPost count

	public List<Employer> findByIndustry(String industry);
//	@Query("Select e from Employer e join e.jobPostingsList j  where j.title =:title")
	public List<Employer> findByJobPostingsListTitle(String title);

	@Query("Select e.employerId, size(e.jobPostingsList) from Employer e")
	public List<Object[]> getEmployerWiseJobCount();


}