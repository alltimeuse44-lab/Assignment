package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.entities.JobPost;

//Provide necessary annotation
@Repository
public interface JobPostRepository extends JpaRepository<JobPost, String>{

	List<JobPost> findBySalaryOfferedGreaterThanEqual(double salaryOffered);
	
	@Query("Select j from JobPost j where j.employerObj.companyName=:companyName and j.employerObj.location =:location")
	List<JobPost> getByCompanyNameAndLocation(@Param("companyName") String companyName,@Param("location") String location);

	

//	 Provide necessary method methods to view JobPosts by salaryOffered, and view 
//	JobPosts by companyName and location	
	
}