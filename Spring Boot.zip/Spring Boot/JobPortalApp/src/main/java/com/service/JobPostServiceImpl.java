package com.service;

import java.util.List;

import com.entities.Employer;
import com.entities.JobPost;
import com.exception.InvalidEmployerException;
import com.exception.InvalidJobPostException;
import com.repository.EmployerRepository;
import com.repository.JobPostRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JobPostServiceImpl implements IJobPostService {

	// Provide necessary Annotation
	@Autowired
	private JobPostRepository jobRepository;

	// Provide necessary Annotation
	@Autowired
	private EmployerRepository empRepository;

	public JobPost addJobPost(JobPost jobPostObj, String employerId) throws InvalidEmployerException
	{
		Employer employer = empRepository.findById(employerId).orElseThrow(()->new InvalidEmployerException());
		jobPostObj.setEmployerObj(employer);
		return jobRepository.save(jobPostObj);
	}
	
	public JobPost updateOfferedSalary(String jobId, double salaryOffered) throws InvalidJobPostException
	{
		JobPost jobPost = jobRepository.findById(jobId).orElseThrow(()->new InvalidJobPostException());
		jobPost.setSalaryOffered(salaryOffered);
		return jobRepository.save(jobPost);
	}	
	
	public List<JobPost> viewJobsBySalaryOffered(double salaryOffered)
	{
		return jobRepository.findBySalaryOfferedGreaterThanEqual(salaryOffered);
		
	}
	
	public List<JobPost> viewJobsByCompanyAndLocation(String companyName, String location){
		return jobRepository.getByCompanyNameAndLocation(companyName,location);
	}
	
	public JobPost markJobPostAsClosed(String jobId) throws InvalidJobPostException {
		JobPost jobPost = jobRepository.findById(jobId).orElseThrow(()->new InvalidJobPostException());
		jobRepository.delete(jobPost);
		return jobPost;
	
	}
}
