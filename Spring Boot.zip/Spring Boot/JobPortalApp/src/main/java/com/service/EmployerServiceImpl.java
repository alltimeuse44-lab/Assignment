package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.entities.Employer;
import com.exception.InvalidEmployerException;
import com.repository.EmployerRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployerServiceImpl implements IEmployerService {
		// Provide necessary Annotation
		@Autowired
		private EmployerRepository empRepository;

		public Employer addEmployer(Employer employerObj) {
			return empRepository.save(employerObj);
		}
		
		public Employer updateLocation(String employerId, String location) throws InvalidEmployerException
		{
			Employer employer = empRepository.findById(employerId).orElseThrow(()->new InvalidEmployerException());
			employer.setLocation(location);
			return empRepository.save(employer);
		}
		
		public Employer viewEmployerById(String employerId) throws InvalidEmployerException
		{
			return empRepository.findById(employerId).orElseThrow(()->new InvalidEmployerException());
		}
		
		public List<Employer> viewEmployersByIndustry(String industry)
		{
			return empRepository.findByIndustry(industry);
		}
		
		public List<Employer> viewEmployersByJobTitle(String title){
			return empRepository.findByJobPostingsListTitle(title);
		}
		
		public Map<String,Integer> getEmployerWiseJobCount(){
			Map<String, Integer> resultMap = new HashMap<>();
			List<Object[]> list = empRepository.getEmployerWiseJobCount();
			for(Object[] obj: list) {
				resultMap.put((String)(obj[0]), (int)obj[1]);
			}
			return resultMap;
		}
		
}
