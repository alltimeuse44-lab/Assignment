


package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entities.ShowInfo;

import jakarta.persistence.Tuple;

//Provide necessary annotation
@Repository
public interface ShowRepository extends JpaRepository<ShowInfo,String> {

	// Provide necessary methods to view shows by genre and language and to get the show wise ticket count
    public List<ShowInfo> findByGenreAndLanguage(String genre,String language);
    
    /*
    @Query(value="Select s.showObj as show,COUNT(*) as count from Booking s GROUP BY s.showObj")
    public List<Tuple> getShowWiseTicketCount();
    */
}
