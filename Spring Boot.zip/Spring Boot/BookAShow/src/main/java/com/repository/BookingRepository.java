package com.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.entities.Booking;

// Provide necessary annotation
@Repository
public interface BookingRepository extends JpaRepository<Booking,String>  {

    // Provide necessary methods to view bookings by date and to view bookings by show id
	public List<Booking> findByBookingDate(LocalDate date);
	@Query(value="Select b from Booking b where show_id=:id", nativeQuery=true)
	public List<Booking> findByShowId(@Param(value="id") String id);
    
}
