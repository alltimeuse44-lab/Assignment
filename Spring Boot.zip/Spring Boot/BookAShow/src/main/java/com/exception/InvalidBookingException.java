package com.exception;

public class InvalidBookingException extends Exception {
    public InvalidBookingException() {
		
	}
}
