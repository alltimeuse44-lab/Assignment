package com.exception;


import java.time.LocalDate;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
		
		ExceptionResponse respo=new ExceptionResponse(
				LocalDate.now(),
				ex.getMessage(),
				request.getDescription(false),
				HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase()
				);
		
		return new ResponseEntity<Object>(respo,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(RuntimeException.class)
	public final ResponseEntity<ExceptionResponse> handleNotFoundException(RuntimeException ex, WebRequest request) {
		
		// Fill the code here
		ExceptionResponse exception=new ExceptionResponse(
				LocalDate.now(),ex.getMessage(),request.getDescription(false),HttpStatus.NOT_FOUND.getReasonPhrase()
				);
		
		return new ResponseEntity<ExceptionResponse>(exception,HttpStatus.NOT_FOUND);	
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
		HttpHeaders headers, HttpStatusCode status, WebRequest request) {	
		    
		    // Fill the code here
//		ExceptionResponse respo=new ExceptionResponse(LocalDate.now(),ex.getMessage(),request.toString()
//				,HttpStatus.BAD_REQUEST.getReasonPhrase());
		
		    
		return new ResponseEntity<Object>(ex.getMessage(),HttpStatus.BAD_REQUEST);
	}
}