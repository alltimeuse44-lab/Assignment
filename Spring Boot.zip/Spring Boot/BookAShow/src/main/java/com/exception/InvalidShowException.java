package com.exception;

public class InvalidShowException extends Exception {
    public InvalidShowException() {
		
	}
}
