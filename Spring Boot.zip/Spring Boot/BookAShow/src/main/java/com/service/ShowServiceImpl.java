package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.entities.ShowInfo;
import com.exception.InvalidShowException;
import com.repository.ShowRepository;

import jakarta.persistence.Tuple;

@Service
public class ShowServiceImpl implements IShowService {

    // Provide necessary Annotation
	@Autowired
    private ShowRepository showRepository;

   
    public ShowInfo addShow(ShowInfo show) {
         // fill code
	    return showRepository.save(show);
    }

   
    public ShowInfo updateShowDuration(String showId, int duration) throws InvalidShowException {
        // fill code
    	ShowInfo show=showRepository.findById(showId).orElseThrow(()->new InvalidShowException());
    	show.setDuration(duration);
	    return showRepository.save(show);
    	
    }

 
    public ShowInfo viewShowById(String showId) throws InvalidShowException {
        // fill code
    	ShowInfo show=showRepository.findById(showId).orElseThrow(()->new InvalidShowException());
	    return show;
    	
    }

  
    public List<ShowInfo> viewShowsByGenreAndLanguage(String genre, String language) {
        // fill code
	    return showRepository.findByGenreAndLanguage(genre, language);
    	
    }

   
    public Map<String, Integer> getShowWiseTicketCount() {
    	 // fill code
    	
    	List<ShowInfo> list=showRepository.findAll();
    	Map<String,Integer> ans=new HashMap<>();
    	for(ShowInfo show:list) {
    		
    		ans.put(show.getTitle(),show.getBookingList().size());
    	}
    	
	    return ans;
    }
}
