
package com.service;

import java.util.List;
import java.util.Map;

import com.entities.ShowInfo;
import com.exception.InvalidShowException;

public interface IShowService {
    public ShowInfo addShow(ShowInfo show);
    public ShowInfo updateShowDuration(String showId, int duration) throws InvalidShowException;
    public ShowInfo viewShowById(String showId) throws InvalidShowException;
    public List<ShowInfo> viewShowsByGenreAndLanguage(String genre, String language);
   public  Map<String, Integer> getShowWiseTicketCount();
}
