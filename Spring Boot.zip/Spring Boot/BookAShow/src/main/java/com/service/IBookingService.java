package com.service;

import java.time.LocalDate;
import java.util.List;

import com.entities.Booking;
import com.exception.InvalidBookingException;
import com.exception.InvalidShowException;

public interface IBookingService {
	public Booking bookAShow(Booking booking, String showId) throws InvalidShowException;
	public Booking updateTicketCount(String bookingId, int ticketCount) throws InvalidBookingException;
	public List<Booking> viewBookingsByDate(LocalDate bookingDate);
	public List<Booking> viewBookingsByShowId(String showId);
	public Booking cancelBooking(String bookingId) throws InvalidBookingException;
}
