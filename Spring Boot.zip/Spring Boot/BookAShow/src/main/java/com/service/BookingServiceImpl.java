package com.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entities.Booking;
import com.entities.ShowInfo;
import com.exception.InvalidBookingException;
import com.exception.InvalidShowException;
import com.repository.BookingRepository;
import com.repository.ShowRepository;

@Service
public class BookingServiceImpl implements IBookingService {

    // Provide necessary Annotation
	@Autowired
    private BookingRepository bookingRepository;

   // Provide necessary Annotation
	@Autowired
    private ShowRepository showRepository;

   
    public Booking bookAShow(Booking booking, String showId) throws InvalidShowException {
        ShowInfo show=showRepository.findById(showId).orElseThrow(()->new InvalidShowException());
		// Fill the code
        booking.setShowObj(show);
		return bookingRepository.save(booking);
    	
    }

   
    public Booking updateTicketCount(String bookingId, int ticketCount) throws InvalidBookingException {
        
		// Fill the code
    	Booking booking=bookingRepository.findById(bookingId).orElseThrow(()->new InvalidBookingException());
    	booking.setTicketCount(ticketCount);
		return bookingRepository.save(booking);
    
    }

  
    public List<Booking> viewBookingsByDate(LocalDate bookingDate) {
    
		// Fill the code
		return bookingRepository.findByBookingDate(bookingDate);
    	
    }

  
    public List<Booking> viewBookingsByShowId(String showId) {
        
		// Fill the code
    	List<Booking> list=bookingRepository.findAll();
    	List<Booking> ans=new ArrayList<>();
    	for(Booking book:list) {
    		if(book.getShowObj().getShowId().equals(showId)) {
    			ans.add(book);
    		}
    	}
		return ans;
    	
    }

   
    public Booking cancelBooking(String bookingId) throws InvalidBookingException {
       
		// Fill the code
    	Booking booking =bookingRepository.findById(bookingId).orElseThrow(()->new InvalidBookingException());
    	bookingRepository.delete(booking);
		return booking;
    	
    }
}
