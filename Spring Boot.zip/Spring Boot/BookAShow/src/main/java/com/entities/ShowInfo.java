package com.entities;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;


//Provide necessary Annotation wherever necessary
// Use appropriate lombok annotations for auto-generating constructor/getter/setter 
// OR manually define the constructor/getter/setter methods, but not both.
@Data
@AllArgsConstructor
@Entity
public class ShowInfo {
	@Id
	@NotNull(message="Provide value for show Id")
    private String showId;
	@NotNull(message="Provide value for title")
    private String title;
	@NotNull(message="Provide value for language")
    private String language;
	@NotNull(message="Provide value for genre")
    private String genre;
	@NotNull(message="Provide value for venue")
    private String venue;
	@FutureOrPresent(message="Start date should be either current or future date")
    private LocalDate startDate;
	@Min(value=30,message="Duration should be in between 30 and 240")
	@Max(value=240,message="Duration should be in between 20 and 240")
    private int duration;
	@Positive(message="Ticket price should be greater than zero")
    private double ticketPrice;
    
    // Provide necessary annotations
    @OneToMany(mappedBy="showObj")
    private List<Booking> bookingList;
    
    public ShowInfo()
    {
        super();
    }
}
