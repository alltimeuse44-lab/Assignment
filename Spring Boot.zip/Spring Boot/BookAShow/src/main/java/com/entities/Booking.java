package com.entities;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;


//Provide necessary Annotation wherever necessary
// Use appropriate lombok annotations for auto-generating constructor/getter/setter 
// OR manually define the constructor/getter/setter methods, but not both.
@Data
@AllArgsConstructor
@Entity
public class Booking {

   @Id
   @NotNull(message="Provide value for booking Id")
    private String bookingId;
   @FutureOrPresent(message="Booking date should be either current or future date")
    private LocalDate bookingDate;
   @NotNull(message="Provide value for booked by")
    private String bookedBy;
   @NotNull(message="Provide value for contact number")
    private String contactNumber;
   @Positive(message="Ticket count should be greater than zero")
    private int ticketCount;
   @NotNull(message="Provide value for payment status")
    private String paymentStatus;

    // Provide necessary Annotations
    @ManyToOne
    @JoinColumn(name="show_id",referencedColumnName="showId")
    private ShowInfo showObj;
    
    
    public Booking()
    {
        super();
    }
}
