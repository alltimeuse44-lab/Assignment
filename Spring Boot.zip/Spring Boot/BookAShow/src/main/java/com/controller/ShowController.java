package com.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entities.ShowInfo;
import com.exception.InvalidShowException;
import com.service.IShowService;

import jakarta.validation.Valid;

//Provide necessary Annotation
@RestController
public class ShowController {

    // Provide necessary Annotation
	@Autowired
    private IShowService showService;

    // Provide necessary Annotation and fill code in the below methods
   @PostMapping("/addShow")
    public ResponseEntity<ShowInfo> addShow(@Valid @RequestBody ShowInfo show) {
        return ResponseEntity.ok(showService.addShow(show));
    }
    
    @PutMapping("/updateShowDuration/{showId}/{duration}")
    public ResponseEntity<ShowInfo> updateShowDuration( @PathVariable String showId, @PathVariable int duration) throws InvalidShowException {
        return ResponseEntity.ok(showService.updateShowDuration(showId, duration));
    }
    
    @GetMapping("/viewShowById/{showId}")
    public ResponseEntity<ShowInfo> viewShowById( @PathVariable String showId) throws InvalidShowException {
        return ResponseEntity.ok(showService.viewShowById(showId));
    }
    
    @GetMapping("/viewShowsByGenreAndLanguage/{genre}/{language}")
    public ResponseEntity<List<ShowInfo>> viewShowsByGenreAndLanguage( @PathVariable String genre,  @PathVariable String language) {
        return ResponseEntity.ok(showService.viewShowsByGenreAndLanguage(genre, language));
    }
    
   @GetMapping("/getShowWiseTicketCount")
    public ResponseEntity<Map<String, Integer>> getShowWiseTicketCount() {
    	
        return null;
    }
}
