package com.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entities.Booking;
import com.exception.InvalidBookingException;
import com.exception.InvalidShowException;
import com.service.IBookingService;

import jakarta.validation.Valid;

//Provide necessary Annotation
@RestController

public class BookingController {

    //Provide necessary Annotation
	@Autowired
    private IBookingService bookingService;

	// Provide necessary Annotation and fill code in the below methods

	@PostMapping("/bookAShow/{showId}")
    public ResponseEntity<Booking> bookAShow( @Valid @RequestBody Booking booking, @PathVariable String showId) throws InvalidShowException {
        return ResponseEntity.ok(bookingService.bookAShow(booking, showId));
    }

    @PutMapping("/updateTicketCount/{bookingId}/{ticketCount}")
    public ResponseEntity<Booking> updateTicketCount( @PathVariable String bookingId,  @PathVariable int ticketCount) throws InvalidBookingException {
        return ResponseEntity.ok(bookingService.updateTicketCount(bookingId, ticketCount));
    }

   @GetMapping("/viewBookingsByDate/{bookingDate}")
    public ResponseEntity<List<Booking>> viewBookingsByDate( @PathVariable LocalDate bookingDate) {
       
        return ResponseEntity.ok(bookingService.viewBookingsByDate(bookingDate));
    }

   @GetMapping("/viewBookingsByShowId/{showId}")
    public ResponseEntity<List<Booking>> viewBookingsByShowId( @PathVariable String showId) {
        return ResponseEntity.ok(bookingService.viewBookingsByShowId(showId));
    }

    @DeleteMapping("/cancelBooking/{bookingId}")
    public ResponseEntity<Booking> cancelBooking(@PathVariable  String bookingId) throws InvalidBookingException {
        return ResponseEntity.ok(bookingService.cancelBooking(bookingId));
    }
}
