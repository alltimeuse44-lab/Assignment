package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entities.Assessment;
import com.exception.InvalidCourseException;
import com.exception.InvalidAssessmentException;
import com.service.IAssessmentService;

//Provide necessary Annotation
@RestController
public class AssessmentController {

    //Provide necessary Annotation
	@Autowired
    private IAssessmentService assessmentService;

   // Provide necessary Annotation and fill code in the below methods

    @PostMapping("/addAssessment/{courseId}")
    public ResponseEntity<Assessment> addAssessment(@RequestBody Assessment assessment, @PathVariable String courseId) throws InvalidCourseException {

    	return new ResponseEntity<Assessment>(assessmentService.addAssessment(assessment, courseId),HttpStatus.OK);
        //return null;
    }

    @PutMapping("/updatePassPercentage/{assessmentId}/{passPercentage}")
    public ResponseEntity<Assessment> updatePassPercentage(@PathVariable String assessmentId, @PathVariable float passPercentage) throws InvalidAssessmentException {

    	return new ResponseEntity<Assessment>(assessmentService.updatePassPercentage(assessmentId, passPercentage),HttpStatus.OK);
        //return null;
    }

    @GetMapping("/viewProctoredAssessments")
    public ResponseEntity<List<Assessment>> viewProctoredAssessments() {

    	return new ResponseEntity<List<Assessment>>(assessmentService.viewProctoredAssessments(),HttpStatus.OK);
        //return null;
    }

    @GetMapping("/viewAssessmentsByCourseId/{courseId}")
    public ResponseEntity<List<Assessment>> viewAssessmentsByCourseId(@PathVariable String courseId) {

    	return new ResponseEntity<List<Assessment>>(assessmentService.viewAssessmentsByCourseId(courseId),HttpStatus.OK);
        //return null;
    }

    @DeleteMapping("/removeAssessment/{assessmentId}")
    public ResponseEntity<Assessment> removeAssessment(@PathVariable String assessmentId) throws InvalidAssessmentException {

    	return new ResponseEntity<Assessment>(assessmentService.removeAssessment(assessmentId),HttpStatus.OK);
        //return null;
    }
}
