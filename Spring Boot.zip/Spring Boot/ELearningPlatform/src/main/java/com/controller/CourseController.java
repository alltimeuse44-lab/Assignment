package com.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entities.Course;
import com.exception.InvalidCourseException;
import com.service.ICourseService;

//Provide necessary Annotation
@RestController
public class CourseController {

    //Provide necessary Annotation
	@Autowired
    private ICourseService courseService;

    // Provide necessary Annotation and fill code in the below methods
    @PostMapping("/addCourse")
    public ResponseEntity<Course> addCourse(@RequestBody Course course) {
        
        return new ResponseEntity<Course>(courseService.addCourse(course),HttpStatus.OK);
    }
    
    @PutMapping("/updateFee/{courseId}/{fee}")
    public ResponseEntity<Course> updateFee(@PathVariable String courseId, @PathVariable double fee) throws InvalidCourseException {

        return new ResponseEntity<Course>(courseService.updateFee(courseId, fee),HttpStatus.OK);
    }
    
    @GetMapping("/viewCourseById/{courseId}")
    public ResponseEntity<Course> viewCourseById(@PathVariable String courseId) throws InvalidCourseException {

        return new ResponseEntity<Course>(courseService.viewCourseById(courseId),HttpStatus.OK);
    }
    
   
    @GetMapping("/viewCoursesByTitleAndLevel/{title}/{level}")
    public ResponseEntity<List<Course>> viewCoursesByTitleAndLevel(@PathVariable String title, @PathVariable String level) {

        return new ResponseEntity<List<Course>>(courseService.viewCoursesByTitleAndLevel(title, level),HttpStatus.OK);
    }
    
    @GetMapping("/getAssessmentTypeCountCourseWise/{assessmentType}")
    public ResponseEntity<Map<String, Integer>> getAssessmentTypeCountCourseWise(@PathVariable String assessmentType) {

        return new ResponseEntity<Map<String,Integer>>(courseService.getAssessmentTypeCountCourseWise(assessmentType),HttpStatus.OK);
    }
}
