package com.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entities.Course;

//Provide necessary annotation
@Repository
public interface CourseRepository  extends JpaRepository<Course, String>{

	// Provide necessary methods to view courses by title and level and to get the assessmentType count coursewise
	@Query(value="Select u from course u",nativeQuery=true)
	List<Course> findByCoursesByTitleAndLevel(String title,String level);
	
	@Query(value="Select u from course u",nativeQuery=true)
	List<Object[]> findAssessmentTypeCountCourseWise(String assessmentType);
   
}
