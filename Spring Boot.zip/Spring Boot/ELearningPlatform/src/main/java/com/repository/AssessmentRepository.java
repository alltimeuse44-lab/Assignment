package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entities.Assessment;

//Provide necessary annotation
@Repository
public interface AssessmentRepository  extends JpaRepository<Assessment, String>{

	// Provide necessary methods to view assessments that are proctored and to view assessments by course id
	@Query(value="Select a from Assessment a",nativeQuery=true)
	List<Assessment> findByProctoredAssessment();
	
	@Query(value="Select a from Assessment a",nativeQuery=true)
	List<Assessment> findByAssessmentsByCourseId(String courseId);
}
