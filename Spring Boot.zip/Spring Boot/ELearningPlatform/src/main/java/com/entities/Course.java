package com.entities;

import java.util.List;

import org.hibernate.validator.constraints.Range;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

//Provide necessary Annotation wherever necessary
// Use appropriate lombok annotations for auto-generating constructor/getter/setter 
// OR manually define the constructor/getter/setter methods, but not both.
@Data
@Getter
@Setter
@AllArgsConstructor
@Entity
public class Course {

   // Provide necessary Annotation
	@Id
	@NotEmpty(message="courseId should not be empty")
	@Column(name = "course_id", length = 25)
    private String courseId;
	@NotEmpty(message="title should not be empty")
	@Column(name="title", length=25)
    private String title;
	@NotEmpty(message="category should not be empty")
	@Column(name = "category", length=25)
    private String category;
	@NotEmpty(message="level should not be empty")
	@Column(name="level", length=25)
    private String level;
	@NotEmpty(message="instructor should not be empty")
	@Column(name="instructor", length=25)
    private String instructor;
	@Min(value=30, message="duration should be a greater than 30")
	@Column(name="duration", length=11)
    private int duration;
	@PositiveOrZero(message="fee should be zero or a positive value")
    private double fee;
	@NotEmpty(message="language should not be empty")
	@Column(name="language", length=25)
    private String language;
	@Range(message="rating should be between 1 and 5")
    private float rating;
    // Provide necessary Annotations
	@OneToMany(mappedBy = "courseObj")
    private List<Assessment> assessmentList;

	public Course()
	{
           super();
	}
}
