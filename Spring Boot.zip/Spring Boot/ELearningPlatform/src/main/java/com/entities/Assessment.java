package com.entities;

import java.time.LocalDate;

import org.hibernate.validator.constraints.Range;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

//Provide necessary Annotation wherever necessary
// Use appropriate lombok annotations for auto-generating constructor/getter/setter 
// OR manually define the constructor/getter/setter methods, but not both.
@Data
@Getter
@Setter
@AllArgsConstructor
@Entity
public class Assessment {

    // Provide necessary Annotation
	@Id
	@NotEmpty(message="assessmentId should not be empty")
	@Column(name="assessment_id", length=25)
    private String assessmentId;
	@NotEmpty(message="assessmentName should not be empty")
	@Column(name="assessment_name", length=25)
    private String assessmentName;
	@NotEmpty(message="assessmentType should not be empty")
	@Column(name="assessment_type", length=25)
    private String assessmentType;
	@Future(message="assessmentDate should be future date")
    private LocalDate assessmentDate;
	@Min(value=30,message="duration should be greater than or equal to 30")
	@Column(name="duration", length=11)
    private int duration;
	@Positive(message = "totalMarks value should be a positive non-zero number")
	@Column(name="total_marks", length=11)
    private int totalMarks;
	@Range(min=0,max=100,message="passPercentage should be between 0 and 100")
    private float passPercentage;
	@Range(min = 1, max=30, message="weightageshould be between 1 and 50")
	@Column(name="weightage", length=11)
    private int weightage;
	@Column(name="is_proctoring_enabled", length=1)
    private boolean isProctoringEnabled;

    // Provide necessary Annotations
    @ManyToOne
    @JoinColumn(name="course_id")
    private Course courseObj;

	public Assessment()
	{
	    super();
	}

}
