package com.exception;

public class InvalidAssessmentException extends Exception {
    public InvalidAssessmentException() {
		
	}
}
