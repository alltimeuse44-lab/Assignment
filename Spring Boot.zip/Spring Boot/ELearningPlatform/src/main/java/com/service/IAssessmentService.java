package com.service;

import java.util.List;

import com.entities.Assessment;
import com.exception.InvalidAssessmentException;
import com.exception.InvalidCourseException;

public interface IAssessmentService {

  
    public Assessment addAssessment(Assessment assessment, String courseId) throws InvalidCourseException;
    
   
    public Assessment updatePassPercentage(String assessmentId, float passPercentage) throws InvalidAssessmentException;
    
   
    public List<Assessment> viewProctoredAssessments();
    
    
    public List<Assessment> viewAssessmentsByCourseId(String courseId);
    
   
    public Assessment removeAssessment(String assessmentId) throws InvalidAssessmentException;
}
