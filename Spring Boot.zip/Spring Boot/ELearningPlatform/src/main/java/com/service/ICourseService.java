package com.service;

import java.util.List;
import java.util.Map;

import com.entities.Course;
import com.exception.InvalidCourseException;

public interface ICourseService {
    
    
    public Course addCourse(Course course);
    
    
    public Course updateFee(String courseId, double fee) throws InvalidCourseException;
    
    
    public Course viewCourseById(String courseId) throws InvalidCourseException;
    
    
    public List<Course> viewCoursesByTitleAndLevel(String title, String level);
    
    
    public Map<String, Integer> getAssessmentTypeCountCourseWise(String assessmentType);
}
