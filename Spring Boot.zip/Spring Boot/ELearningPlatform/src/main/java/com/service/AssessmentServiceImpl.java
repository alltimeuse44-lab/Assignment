package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entities.Assessment;
import com.exception.InvalidAssessmentException;
import com.exception.InvalidCourseException;
import com.repository.AssessmentRepository;
import com.repository.CourseRepository;

@Service
public class AssessmentServiceImpl implements IAssessmentService {

    // Provide necessary Annotation
	@Autowired
    private AssessmentRepository assessmentRepository;

    // Provide necessary Annotation
	@Autowired
    private CourseRepository courseRepository;

    public Assessment addAssessment( Assessment assessment, String courseId) throws InvalidCourseException {

		// Fill the code
    	Assessment ass = assessmentRepository.findById(courseId).orElseThrow(() -> new InvalidCourseException());
    	if(ass==null)
    	{
    		throw new InvalidCourseException();
    	}
    	else
    	{
    		assessmentRepository.save(assessment);
    	}
    	return assessment;
		
    }

   
    public Assessment updatePassPercentage(String assessmentId, float passPercentage) throws InvalidAssessmentException {

		// Fill the code
    	Assessment ass = assessmentRepository.findById(assessmentId).orElseThrow(() -> new InvalidAssessmentException());
    	if(assessmentId == null)
    	{
    		throw new InvalidAssessmentException();
    	}
    	else
    	{
    		ass.setPassPercentage(passPercentage);
    		assessmentRepository.save(ass);
    	}
    	return ass;
    }

  
    public List<Assessment> viewProctoredAssessments() {

		// Fill the code
		return assessmentRepository.findByProctoredAssessment();      
    }

    
    public List<Assessment> viewAssessmentsByCourseId(String courseId) {

		// Fill the code
//		return assessmentRepository.find   
    	return assessmentRepository.findByAssessmentsByCourseId(courseId);
    }

   
    public Assessment removeAssessment(String assessmentId) throws InvalidAssessmentException {

		// Fill the code
    	Assessment ass = assessmentRepository.findById(assessmentId).orElseThrow(() -> new InvalidAssessmentException());
    	if(ass==null)
    	{
    		throw new InvalidAssessmentException();
    	}
    	else
    	{
    		assessmentRepository.delete(ass);
    	}
    	return ass;
    	
		      
    }
}
