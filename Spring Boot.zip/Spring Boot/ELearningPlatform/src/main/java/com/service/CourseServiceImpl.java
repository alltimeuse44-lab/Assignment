package com.service;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entities.Course;
import com.exception.InvalidCourseException;
import com.repository.CourseRepository;


@Service
public class CourseServiceImpl implements ICourseService {

    // Provide necessary Annotation
	@Autowired
    private CourseRepository courseRepository;

  
    public Course addCourse(Course course) {
        //return courseRepository.save(course);
    	return courseRepository.save(course);
    }

  
    public Course updateFee(String courseId, double fee) throws InvalidCourseException {
       
    	Course course = courseRepository.findById(courseId).orElseThrow(() -> new InvalidCourseException());
    	if(courseId == null)
    	{
    		throw new InvalidCourseException();
    	}
    	else
    	{
    		course.setFee(fee);;
    		courseRepository.save(course);
    	}
    	return course;
        //return null;
    }


    public Course viewCourseById(String courseId) throws InvalidCourseException {
        //return courseRepository.find;
    	Course course = courseRepository.findById(courseId).orElseThrow(() -> new InvalidCourseException());
    	return course;
    }

  
    public List<Course> viewCoursesByTitleAndLevel(String title, String level) {
//        return courseRepository.findByTitleAndLevel(title, level);
    	return courseRepository.findByCoursesByTitleAndLevel(title, level);
    }

   
    public Map<String, Integer> getAssessmentTypeCountCourseWise(String assessmentType) {
       
    	List<Course> list = courseRepository.findAll();
    	Map<String, Integer> map = new HashMap<>();
    	for(Course course:list)
    	{
    		map.put(course.getTitle(),course.getAssessmentList().size());
    	}
        return map;
    }
}
