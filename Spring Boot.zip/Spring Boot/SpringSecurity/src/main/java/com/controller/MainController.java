package com.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class MainController {

	@GetMapping("/")
	public String homePage(HttpServletRequest request) {
		return "Welcome to home page " + request.getSession().getId();
	}
	
}
