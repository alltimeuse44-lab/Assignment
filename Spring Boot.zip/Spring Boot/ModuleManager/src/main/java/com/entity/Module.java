package com.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

//Provide necessary Annotation wherever necessary
@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
public class Module {
	
   // Provide necessary Annotation
	@Id
   private String moduleId;
   private String moduleName;
   private double moduleFee;
   private int duration;
   private String difficultyLevel;

   public Module()
   {
     super();
   }

 }
