package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Module;
import com.exception.InvalidModuleException;
import com.repository.ModuleRepository;

@Service
public class ModuleServiceImpl implements IModuleService {

    // Provide necessary Annotation
	@Autowired
    private ModuleRepository moduleRepository;

 
    public Module addModule(Module module) {
    	return this.moduleRepository.save(module);
    }

    public Module updateModuleFee(String moduleId, double moduleFee) throws InvalidModuleException {
    	
    	Module fee = moduleRepository.findById(moduleId).orElseThrow(()->new InvalidModuleException());
    	fee.setModuleFee(moduleFee);
        return moduleRepository.save(fee);
    }

  
    public Module viewModuleById(String moduleId) throws InvalidModuleException {
        
    	return moduleRepository.findById(moduleId).orElseThrow(()->new InvalidModuleException());
    }
 
    public List<Module> viewAllModules() {
        
    	return moduleRepository.findAll();
    }

  
    public Module deleteModule(String moduleId) throws InvalidModuleException {
    	Module mod = moduleRepository.findById(moduleId).orElseThrow(()->new InvalidModuleException());
    	moduleRepository.delete(mod);
    	return mod;
    }

}
