package com.repository;
import com.entity.Module;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//Provide necessary annotation
@Repository
public interface ModuleRepository extends JpaRepository<Module, String>{

   
}
