package com.entities;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

//Provide necessary Annotation

//@Data
@Setter
@Getter
@AllArgsConstructor
@Entity
public class BankTransaction {

	//Provide necessary Annotation
	@Id
	private String transactionId;
	private String transactionDate;
	private String transactionType;//Deposit or Withdraw
	private double amount;
	@ManyToOne
	@JoinColumn(name = "account_number")
	private Account accountObj;
	
	 public BankTransaction() {
        super();
    }
	
}
