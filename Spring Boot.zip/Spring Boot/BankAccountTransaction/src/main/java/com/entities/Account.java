package com.entities;

import java.util.List;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

//Provide necessary Annotation

@Entity
//@Data
@Setter
@Getter
@AllArgsConstructor
public class Account {
	
	//Provide necessary Annotation
	@Id
	private String accountNumber;
	private String holderName;
	private String phoneNumber;
	private String panNumber;
	private String accountType; //Savings or Current
	private double balanceAmount;
	@OneToMany(mappedBy="accountObj")
	List<BankTransaction> transactions;
	
	public Account()
	    {
	        super();
	    }
	
}
