package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.entities.Account;
import com.entities.BankTransaction;
import com.repository.AccountRepository;
import com.repository.TransactionRepository;

@Component
public class TransactionDAOImpl implements ITransactionDAO {
	
	//Provide code to Inject TransactionRepository and AccountRepository
	//Provide code to Inject AccountRepository, if needed
	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Override
	public BankTransaction insertTransaction(BankTransaction transactionObj,String accountNumber){
		
		//fill code
		Account acc = accountRepository.findById(accountNumber).orElse(null);
		if(acc != null) {
			
			if(transactionObj.getTransactionType().equalsIgnoreCase("Deposit")) {
				acc.setBalanceAmount(acc.getBalanceAmount() + transactionObj.getAmount());
			}else if(transactionObj.getTransactionType().equalsIgnoreCase("Withdraw")) {
				acc.setBalanceAmount(acc.getBalanceAmount() - transactionObj.getAmount());
			}
			transactionObj.setAccountObj(acc);
			transactionRepository.save(transactionObj);
			accountRepository.save(acc);
		}
		
		
		return transactionObj;
	}
	
	@Override
	public List<BankTransaction> viewTransactionByTransactionType(String transactionType)
	{
		//fill code
		
		return transactionRepository.findByTransactionType(transactionType);	
	}
	


}
