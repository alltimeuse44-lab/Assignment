package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.entities.Account;
import com.repository.AccountRepository;

@Component
public class AccountDAOImpl implements IAccountDAO{
	
	//Provide code to Inject AccountRepository
	@Autowired
	private AccountRepository accountRepository;
	
	@Override
	public Account openAccount(Account account) {
		
		//fill code
		accountRepository.save(account);
		return account;
	}
	
	@Override
	public Account viewAccountByAccountNumber(String accountNumber) {
		
		//fill code
		Account acc = accountRepository.findById(accountNumber).get();
		return acc;	
	}



}
