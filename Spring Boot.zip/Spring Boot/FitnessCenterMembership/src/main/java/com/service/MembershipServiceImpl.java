package com.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exception.InvalidMembershipException;
import com.model.Membership;
import com.repository.MembershipRepository;

//Provide necessary annotation
@Service
public class MembershipServiceImpl implements IMembershipService{
	
	//Provide necessary annotation
	@Autowired
	private MembershipRepository membershipRepo;

	public Membership addMembership(Membership membership) {
		// fill the code
		return membershipRepo.save(membership);
	}

	public Membership viewMembershipById(String membershipId) throws InvalidMembershipException {
		// fill the code
		return membershipRepo.findById(membershipId).orElseThrow(()->new InvalidMembershipException());
//		return member;
	}
	
	public List<Membership> viewMembershipsByBenefit(String benefit) {
		// fill the code
		return membershipRepo.findByBenefitsContaining(benefit);
//		List<Membership> list = new ArrayList<>();
//		for(Membership mem: member){
//			list.add(mem);
//		}
//		return list;
	}

	public List<Membership> viewMembershipsByTypeAndAccessHours(String membershipType, int monthlyAccessHours) {
		// fill the code
		return membershipRepo.findByMembershipTypeEqualsAndMonthlyAccessHoursGreaterThan(membershipType,monthlyAccessHours);
//		List<Membership> list=null;
//		for(Membership mem : member) {
//			list.add(mem);
//		}
//		return list;
	} 	  	      	 	    	      	    	      	 	
	
	public Map<String,Integer> getMembershipCountTypeWise() {
		// fill the code
		List<Object[]> member = membershipRepo.findByMembershipCountTypeWise();
		Map<String,Integer> map=new HashMap<>();
		
		for(Object[] obj: member) {
			map.put((String) obj[0], ((Number)obj[1]).intValue());
		}
		return map;
	}
}
