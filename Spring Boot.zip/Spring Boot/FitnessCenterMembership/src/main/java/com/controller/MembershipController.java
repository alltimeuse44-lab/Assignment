package com.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exception.InvalidMembershipException;
import com.model.Membership;
import com.service.IMembershipService;

import jakarta.validation.Valid;


//Provide necessary Annotation
@RestController
public class MembershipController {
	
	//Provide necessary Annotation
	@Autowired
	private IMembershipService membershipService;
	
	//Provide necessary Annotation for the below methods and fill the code
	@PostMapping("/addMembership")
	public ResponseEntity<Membership> addMembership(@Valid @RequestBody Membership membership) {
		return new ResponseEntity<>(membershipService.addMembership(membership),HttpStatus.OK);
	}
	
	@GetMapping("/viewMembershipById/{membershipId}")
	public ResponseEntity<Membership> viewMembershipById(@PathVariable String membershipId) throws InvalidMembershipException{
		return new ResponseEntity<> (membershipService.viewMembershipById(membershipId),HttpStatus.OK);
	}
	
	@GetMapping("/viewMembershipsByBenefit/{benefit}")
	public ResponseEntity<List<Membership>> viewMembershipsByBenefit(@PathVariable String benefit) {
		return new ResponseEntity<>(membershipService.viewMembershipsByBenefit(benefit),HttpStatus.OK);
	}
	
	@GetMapping("/viewMembershipsByTypeAndAccessHours/{membershipType}/{monthlyAccessHours}")
	public ResponseEntity<List<Membership>> viewMembershipsByTypeAndAccessHours( @PathVariable String membershipType, @PathVariable int monthlyAccessHours) {
		return new ResponseEntity<>(membershipService.viewMembershipsByTypeAndAccessHours(membershipType, monthlyAccessHours),HttpStatus.OK);
	}
	
	@GetMapping("/getMembershipCountTypeWise")
	public ResponseEntity<Map<String,Integer>> getMembershipCountTypeWise() {
		return new ResponseEntity<>(membershipService.getMembershipCountTypeWise(),HttpStatus.OK);
	}
}