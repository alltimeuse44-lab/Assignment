package com.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.model.Membership;

//Provide necessary annotation
@Repository
public interface MembershipRepository extends JpaRepository<Membership, String>{

//	List<Membership> findByBenefit(String benefit);
/*
//	@Query("select m from Membership m where benefits= :benefit")
//	List<Membership> findByBenefit(@Param("benefit") String benefit);
	
	List<Membership> findByBenefitsContaining(String benefit);

	List<Membership> findByMembershipTypeEqualsAndMonthlyAccessHoursGreaterThan(String membershipType,
			int monthlyAccessHours);

	@Query("select m.membershipType,Count(m.membershipId) from Membership m group by m.membershipType")
	public List<Object[]> findByMembershipCountTypeWise();
   
   */

	List<Membership> findByBenefitsContaining(String benefit);

	List<Membership> findByMembershipTypeEqualsAndMonthlyAccessHoursGreaterThan(String membershipType, int monthlyAccessHours);
	
	@Query("select m.membershipType,Count(m.membershipId) from Membership m group by m.membershipType")
	List<Object[]> findByMembershipCountTypeWise();

	 // Provide necessary methods to view memberships by benefit, view memberships by membership type and monthly access hours and get membership count for each type
    
}