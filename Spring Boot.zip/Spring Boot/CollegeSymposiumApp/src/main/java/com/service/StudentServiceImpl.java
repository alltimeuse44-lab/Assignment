package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.repository.StudentRepository;
import com.repository.CollegeRepository;
import com.entities.College;
import com.entities.Student;
import com.exception.InvalidCollegeException;
import com.exception.InvalidStudentException;

@Service
public class StudentServiceImpl implements IStudentService{
	
	//Provide necessary annotation
	@Autowired
	private StudentRepository studentRepo;
	
	//Provide necessary annotation
	@Autowired
    private CollegeRepository collegeRepo;

	public Student addStudent(Student student, String collegeId) throws InvalidCollegeException {
		College college = this.collegeRepo.findById(collegeId).orElseThrow(()->new InvalidCollegeException());
		student.setCollegeObj(college);
		return studentRepo.save(student);
	}
	
	public Student updateScore(String studentId, int score) throws InvalidStudentException{
		Student student = this.studentRepo.findById(studentId).orElseThrow(()->new InvalidStudentException());
		
		student.setScore(score);
	return studentRepo.save(student);
	}

	public Student viewStudentById(String studentId) throws InvalidStudentException {
		return this.studentRepo.findById(studentId).orElseThrow(()->new InvalidStudentException());
	}

	public List<Student> viewStudentsByCollegeName(String collegeName) {
		return this.studentRepo.findByCollegeObjCollegeName(collegeName);
	}

	public Student deleteStudent(String studentId) throws InvalidStudentException {
		Student student = studentRepo.findById(studentId).orElseThrow(()->new InvalidStudentException());
		this.studentRepo.delete(student);
		return student;
	}	 	  	      	 		     	     	        	 	


}
