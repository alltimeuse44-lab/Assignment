package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bean.School;

@Repository
public interface SchoolRepository extends JpaRepository<School,String>{

	@Query("Select s From School s Where s.city = :city and Size(s.studentList) = (Select Max(Size(sch.studentList)) From School sch Where sch.city = :city)")
	List<School> findSchoolWithMaximumCount(@Param("city") String city);
}
