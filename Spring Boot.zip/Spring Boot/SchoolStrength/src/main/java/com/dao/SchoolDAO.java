package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.School;
import com.bean.Student;
import com.repository.SchoolRepository;
import com.repository.StudentRepository;

@Service
public class SchoolDAO {
	@Autowired
	private SchoolRepository schoolRepo;
	
	@Autowired
	private StudentRepository studentRepo;
	
	public School addSchool(School school){
	    
	    return schoolRepo.save(school);
		
	}
	
	
	public List<Student> registerStudentToSchool(String schoolId, List<Student> students ) {
		School s1 = schoolRepo.findById(schoolId).get();
		for(Student stud : students) {
			stud.setSchool(s1);
			studentRepo.save(stud);
		}
		return students;
	}

	
	public List<School> schoolWithMaximumStudents(String city){
		return  schoolRepo.findSchoolWithMaximumCount(city);
	}
}
